// TODO: Created this file as part of fixing pyframe.rs and cpython/pyframe.rs
// TODO: Finish defining or moving declarations now in Include/pytypedefs.h

opaque_struct!(pub PyFrameObject);
