opaque_struct!(pub PyArena);
