These algorithms are copies of the algorithms found in the [snowball package](https://github.com/snowballstem/snowball) and are licensed under the [[file:LICENSE][BSD-3 License]].
To compile them to rust code yourself, please use the rust backend of the snowball compiler.

This library ships with these algorithms already compiled to rust.
