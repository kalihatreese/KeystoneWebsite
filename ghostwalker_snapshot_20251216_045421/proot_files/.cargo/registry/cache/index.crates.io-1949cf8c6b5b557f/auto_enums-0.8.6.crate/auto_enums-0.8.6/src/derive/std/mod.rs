// SPDX-License-Identifier: Apache-2.0 OR MIT

/// `std::error`
pub(crate) mod error;
/// `std::io`
pub(crate) mod io;
