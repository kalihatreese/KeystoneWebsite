# Used in PyModule examples.


class Blah:
    pass
