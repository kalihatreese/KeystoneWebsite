[![Build Status](https://travis-ci.org/tantivy-search/fst.svg?branch=master)](https://travis-ci.org/tantivy-search/fst)

tantivy-fst
===


# WARNING: This is not the crate you are looking for.

This crate is a fork of the `fst` crate from Andrew Gallant (alias BurntSushi) to better fit the need of tantivy. 
You are probably looking for the  [fst](https://github.com/BurntSushi/fst) crate


Please do not depend on this crate directly.
