# Examples

- [Basic search](/examples/basic_search.html)
