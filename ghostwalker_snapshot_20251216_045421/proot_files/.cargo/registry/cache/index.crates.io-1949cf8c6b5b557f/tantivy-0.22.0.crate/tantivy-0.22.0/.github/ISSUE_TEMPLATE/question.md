---
name: Question
about: Ask any question about tantivy's usage...

---

Try to be specific about your use case...
