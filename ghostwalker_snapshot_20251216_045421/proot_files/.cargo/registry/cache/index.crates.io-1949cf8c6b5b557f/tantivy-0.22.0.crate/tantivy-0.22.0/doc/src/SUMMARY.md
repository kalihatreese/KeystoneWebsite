# Summary

[Avant Propos](./avant-propos.md)

- [Segments](./basis.md)
- [Defining your schema](./schema.md)
- [Facetting](./facetting.md)
- [Index Sorting](./index_sorting.md)
- [Innerworkings](./innerworkings.md)
  - [Inverted index](./inverted_index.md)
- [Best practise](./inverted_index.md)

[Frequently Asked Questions](./faq.md)
[Examples](./examples.md)
