include!("../examples/vectors.rs"); // TODO: Workaround for cargo not running tests in examples folder rust-lang/cargo#2631.
