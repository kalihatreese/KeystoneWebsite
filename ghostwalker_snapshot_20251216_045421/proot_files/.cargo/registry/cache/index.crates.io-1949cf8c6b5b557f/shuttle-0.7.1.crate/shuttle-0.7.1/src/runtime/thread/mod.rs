pub(crate) mod continuation;

pub(crate) use continuation::switch;
