# Tantivy Query Grammar

This crate is used by tantivy to parse queries.
