//! Future types.

pub use super::{
    into_make_service::IntoMakeServiceFuture,
    route::{InfallibleRouteFuture, RouteFuture},
};
