# fastrace-macro

[![Documentation](https://docs.rs/fastrace-macro/badge.svg)](https://docs.rs/fastrace-macro/)
[![Crates.io](https://img.shields.io/crates/v/fastrace-macro.svg)](https://crates.io/crates/fastrace-macro)
[![LICENSE](https://img.shields.io/github/license/fast/fastrace.svg)](https://github.com/fast/fastrace/blob/main/LICENSE)

An attribute macro designed to eliminate boilerplate code for [`fastrace`](https://crates.io/crates/fastrace).
