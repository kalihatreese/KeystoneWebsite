// Copyright 2020 TiKV Project Authors. Licensed under Apache-2.0.

use fastrace::trace;

#[trace(properties = { "a": "{{b}" })]
fn f(b: u8) {}

fn main() {}
