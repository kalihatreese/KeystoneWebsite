//! Asynchronous signal handling.

pub use tokio::signal::ctrl_c;
