# rust http headers

[![crates.io](https://img.shields.io/crates/v/headers.svg)](https://crates.io/crates/headers)
[![Released API docs](https://docs.rs/headers/badge.svg)](https://docs.rs/headers)
[![MIT licensed](https://img.shields.io/badge/license-MIT-blue.svg)](./LICENSE)
[![Build Status](https://github.com/hyperium/headers/workflows/CI/badge.svg)](https://github.com/hyperium/headers/actions?query=workflow%3ACI)

Typed HTTP headers.
