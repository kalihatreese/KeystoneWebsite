# proptest-derive

Custom-derive for the Arbitrary trait of proptest.

This is currently experimental.