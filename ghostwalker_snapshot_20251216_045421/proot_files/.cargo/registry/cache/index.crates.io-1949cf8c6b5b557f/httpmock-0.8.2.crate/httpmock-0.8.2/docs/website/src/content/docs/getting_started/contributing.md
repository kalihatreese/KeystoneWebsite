---
title: Contributing
description: Explains how individuals and companies can contribute to this project.
---

Everyone is welcome to contribute to this project. 
