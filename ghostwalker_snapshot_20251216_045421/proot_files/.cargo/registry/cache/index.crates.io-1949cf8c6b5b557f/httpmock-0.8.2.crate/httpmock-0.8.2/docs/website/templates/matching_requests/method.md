---
title: Method
description: Using request matchers to specify which requests should respond. TODO
---

This section describes matcher functions designed to target and match the method in incoming HTTP requests,
such as `GET`, `POST`, etc.

## method
{{{docs.when.method}}}

## method_not
{{{docs.when.method_not}}}
