---
title: Request Matchers
description: Using request matchers to specify which requests should respond. TODO
---

This section describes matcher functions designed to target and match the TCP port in incoming HTTP requests.
These matchers are especially useful when using the proxy and record-and-playback features of `httpmock`.

## port
{{{docs.when.port}}}

## port_not
{{{docs.when.port_not}}}
