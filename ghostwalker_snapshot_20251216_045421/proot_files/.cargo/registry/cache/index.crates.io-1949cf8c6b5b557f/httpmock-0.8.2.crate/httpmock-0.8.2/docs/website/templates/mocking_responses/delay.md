---
title: Network Delay
description: Demonstrates how to simulate network delay.
---

This section describes functions designed to simulate network issues, such as latency (delay).

### delay
{{{docs.then.delay}}}

## respond_with
{{{docs.then.respond_with}}}