# Contributing

The `crossterm` crate
[contributing guidelines](https://github.com/crossterm-rs/crossterm/blob/master/docs/CONTRIBUTING.md) applies.
