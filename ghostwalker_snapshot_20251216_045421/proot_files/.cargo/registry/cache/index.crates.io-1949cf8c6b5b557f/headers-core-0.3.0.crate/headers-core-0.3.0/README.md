# Typed HTTP Headers: core `Header` trait

WIP
