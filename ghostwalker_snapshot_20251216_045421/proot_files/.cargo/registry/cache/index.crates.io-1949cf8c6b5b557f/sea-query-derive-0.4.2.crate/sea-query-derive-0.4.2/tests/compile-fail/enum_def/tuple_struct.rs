use sea_query_derive::enum_def;

#[enum_def]
struct Hello(String);

fn main() {}
