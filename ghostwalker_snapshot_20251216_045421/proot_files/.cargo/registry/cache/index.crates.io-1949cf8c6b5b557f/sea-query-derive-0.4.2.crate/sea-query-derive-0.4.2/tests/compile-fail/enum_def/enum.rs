use sea_query_derive::enum_def;

#[enum_def]
enum Hello {
    Name,
}

fn main() {}
