use sea_query::Iden;

#[derive(Iden)]
struct User {
    id: usize,
}

fn main() {}
