* **`0.1.0`**
  * Initial implementation
* **`0.1.1`**
  * Technical improvements
* **`0.1.2`**
  * added a trait to obtain the result from value
  * added a method to get the cloned as Value
  * change the name of the general method*
* **`0.1.4`**
  * add an ability to use references instead of values
  * fix some clippy issues
* **`0.1.5`**
  * correct grammar for `$.[..]`
* **`0.1.6`**
  * add logical OR and logical And to filters
  * fix bugs with objects in filters
  * add internal macros to generate path objects
* **`0.2.0`**
  * add json path value as a result for the library  
  * add functions (size)
  * change a logical operator `size` into function `size()`
* **`0.2.1`**
  * changed the contract for length() function.
* **`0.2.2`**
  * add ..*
* **`0.2.5`**
  * build for tags  
* **`0.2.6`**
  * make parser mod public  
* **`0.3.0`**
  * introduce the different behaviour for empty results and non-existing result
* **`0.3.2`**
  * make jsonpath inst cloneable.
* **`0.3.3`**
  * fix a bug with the logical operators
* **`0.3.4`**
  * add a result as a path
* **`0.3.5`**
  * add `!` negation operation in filters
  * allow using  () in filters

