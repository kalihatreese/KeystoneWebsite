# proptest-state-machine

The state machine testing support provides a strategy and convenience runner macro for a sequential state machine. To learn more, please consult [state machine page in the Proptest book](https://proptest-rs.github.io/proptest/proptest/state-machine.html).
