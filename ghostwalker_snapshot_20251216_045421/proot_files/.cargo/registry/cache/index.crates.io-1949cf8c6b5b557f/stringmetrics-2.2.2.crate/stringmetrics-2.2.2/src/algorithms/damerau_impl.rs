// Using the "optimal string alignment distance" from wikipedia
pub fn damerau_levenshtein(_a: &str, _b: &str) -> u32 {
    0
}
