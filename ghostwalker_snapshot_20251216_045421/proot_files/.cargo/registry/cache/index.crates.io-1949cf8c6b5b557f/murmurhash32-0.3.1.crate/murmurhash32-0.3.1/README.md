# murmurhash32

A simple implementation of murmurhash32_2
