[*] Put your product zip files in: /data/data/com.termux/files/home/keystone-payment-engine/downloads
